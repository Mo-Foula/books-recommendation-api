--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.6 (Debian 14.6-1.pgdg110+1)
-- Dumped by pg_dump version 15.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "book-recommendation";
--
-- Name: book-recommendation; Type: DATABASE; Schema: -; Owner: db-user-foula
--

CREATE DATABASE "book-recommendation" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE "book-recommendation" OWNER TO "db-user-foula";

\connect -reuse-previous=on "dbname='book-recommendation'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: db-user-foula
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO "db-user-foula";

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: db-user-foula
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: author; Type: TABLE; Schema: public; Owner: db-user-foula
--

CREATE TABLE public.author (
    id integer NOT NULL,
    name character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    birth_date date NOT NULL,
    gender character varying NOT NULL
);


ALTER TABLE public.author OWNER TO "db-user-foula";

--
-- Name: author_id_seq; Type: SEQUENCE; Schema: public; Owner: db-user-foula
--

CREATE SEQUENCE public.author_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.author_id_seq OWNER TO "db-user-foula";

--
-- Name: author_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db-user-foula
--

ALTER SEQUENCE public.author_id_seq OWNED BY public.author.id;


--
-- Name: book; Type: TABLE; Schema: public; Owner: db-user-foula
--

CREATE TABLE public.book (
    id integer NOT NULL,
    name character varying NOT NULL,
    number_of_pages integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    author_id integer
);


ALTER TABLE public.book OWNER TO "db-user-foula";

--
-- Name: book_id_seq; Type: SEQUENCE; Schema: public; Owner: db-user-foula
--

CREATE SEQUENCE public.book_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.book_id_seq OWNER TO "db-user-foula";

--
-- Name: book_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db-user-foula
--

ALTER SEQUENCE public.book_id_seq OWNED BY public.book.id;


--
-- Name: books_categories; Type: TABLE; Schema: public; Owner: db-user-foula
--

CREATE TABLE public.books_categories (
    book_id integer NOT NULL,
    category_id integer NOT NULL
);


ALTER TABLE public.books_categories OWNER TO "db-user-foula";

--
-- Name: books_readings; Type: TABLE; Schema: public; Owner: db-user-foula
--

CREATE TABLE public.books_readings (
    id integer NOT NULL,
    first_page integer NOT NULL,
    pages_count integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    book_id integer,
    user_id integer
);


ALTER TABLE public.books_readings OWNER TO "db-user-foula";

--
-- Name: books_readings_id_seq; Type: SEQUENCE; Schema: public; Owner: db-user-foula
--

CREATE SEQUENCE public.books_readings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.books_readings_id_seq OWNER TO "db-user-foula";

--
-- Name: books_readings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db-user-foula
--

ALTER SEQUENCE public.books_readings_id_seq OWNED BY public.books_readings.id;


--
-- Name: category; Type: TABLE; Schema: public; Owner: db-user-foula
--

CREATE TABLE public.category (
    id integer NOT NULL,
    name character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.category OWNER TO "db-user-foula";

--
-- Name: category_id_seq; Type: SEQUENCE; Schema: public; Owner: db-user-foula
--

CREATE SEQUENCE public.category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.category_id_seq OWNER TO "db-user-foula";

--
-- Name: category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db-user-foula
--

ALTER SEQUENCE public.category_id_seq OWNED BY public.category.id;


--
-- Name: claim; Type: TABLE; Schema: public; Owner: db-user-foula
--

CREATE TABLE public.claim (
    id integer NOT NULL,
    claim_name character varying NOT NULL,
    module_name character varying NOT NULL,
    read boolean NOT NULL,
    "create" boolean NOT NULL,
    update boolean NOT NULL,
    delete boolean NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.claim OWNER TO "db-user-foula";

--
-- Name: claim_id_seq; Type: SEQUENCE; Schema: public; Owner: db-user-foula
--

CREATE SEQUENCE public.claim_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.claim_id_seq OWNER TO "db-user-foula";

--
-- Name: claim_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db-user-foula
--

ALTER SEQUENCE public.claim_id_seq OWNED BY public.claim.id;


--
-- Name: role; Type: TABLE; Schema: public; Owner: db-user-foula
--

CREATE TABLE public.role (
    id integer NOT NULL,
    name character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.role OWNER TO "db-user-foula";

--
-- Name: role_id_seq; Type: SEQUENCE; Schema: public; Owner: db-user-foula
--

CREATE SEQUENCE public.role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.role_id_seq OWNER TO "db-user-foula";

--
-- Name: role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db-user-foula
--

ALTER SEQUENCE public.role_id_seq OWNED BY public.role.id;


--
-- Name: roles_claims; Type: TABLE; Schema: public; Owner: db-user-foula
--

CREATE TABLE public.roles_claims (
    role_id integer NOT NULL,
    claim_id integer NOT NULL
);


ALTER TABLE public.roles_claims OWNER TO "db-user-foula";

--
-- Name: user; Type: TABLE; Schema: public; Owner: db-user-foula
--

CREATE TABLE public."user" (
    id integer NOT NULL,
    email character varying NOT NULL,
    phone character varying NOT NULL,
    password character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    role_id integer
);


ALTER TABLE public."user" OWNER TO "db-user-foula";

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: db-user-foula
--

CREATE SEQUENCE public.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_id_seq OWNER TO "db-user-foula";

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db-user-foula
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: users_books_readings; Type: TABLE; Schema: public; Owner: db-user-foula
--

CREATE TABLE public.users_books_readings (
    book_id integer NOT NULL,
    user_id integer NOT NULL,
    unique_read_pages integer NOT NULL,
    total_read_pages integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users_books_readings OWNER TO "db-user-foula";

--
-- Name: users_profiles; Type: TABLE; Schema: public; Owner: db-user-foula
--

CREATE TABLE public.users_profiles (
    id integer NOT NULL,
    first_name character varying NOT NULL,
    last_name character varying NOT NULL,
    gender character varying NOT NULL,
    address character varying NOT NULL,
    birth_date date NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    auth_user_id integer
);


ALTER TABLE public.users_profiles OWNER TO "db-user-foula";

--
-- Name: users_profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: db-user-foula
--

CREATE SEQUENCE public.users_profiles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_profiles_id_seq OWNER TO "db-user-foula";

--
-- Name: users_profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db-user-foula
--

ALTER SEQUENCE public.users_profiles_id_seq OWNED BY public.users_profiles.id;


--
-- Name: author id; Type: DEFAULT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.author ALTER COLUMN id SET DEFAULT nextval('public.author_id_seq'::regclass);


--
-- Name: book id; Type: DEFAULT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.book ALTER COLUMN id SET DEFAULT nextval('public.book_id_seq'::regclass);


--
-- Name: books_readings id; Type: DEFAULT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.books_readings ALTER COLUMN id SET DEFAULT nextval('public.books_readings_id_seq'::regclass);


--
-- Name: category id; Type: DEFAULT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.category ALTER COLUMN id SET DEFAULT nextval('public.category_id_seq'::regclass);


--
-- Name: claim id; Type: DEFAULT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.claim ALTER COLUMN id SET DEFAULT nextval('public.claim_id_seq'::regclass);


--
-- Name: role id; Type: DEFAULT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.role ALTER COLUMN id SET DEFAULT nextval('public.role_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Name: users_profiles id; Type: DEFAULT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.users_profiles ALTER COLUMN id SET DEFAULT nextval('public.users_profiles_id_seq'::regclass);


--
-- Data for Name: author; Type: TABLE DATA; Schema: public; Owner: db-user-foula
--

COPY public.author (id, name, created_at, updated_at, birth_date, gender) FROM stdin;
\.
COPY public.author (id, name, created_at, updated_at, birth_date, gender) FROM '$$PATH$$/3435.dat';

--
-- Data for Name: book; Type: TABLE DATA; Schema: public; Owner: db-user-foula
--

COPY public.book (id, name, number_of_pages, created_at, updated_at, author_id) FROM stdin;
\.
COPY public.book (id, name, number_of_pages, created_at, updated_at, author_id) FROM '$$PATH$$/3421.dat';

--
-- Data for Name: books_categories; Type: TABLE DATA; Schema: public; Owner: db-user-foula
--

COPY public.books_categories (book_id, category_id) FROM stdin;
\.
COPY public.books_categories (book_id, category_id) FROM '$$PATH$$/3432.dat';

--
-- Data for Name: books_readings; Type: TABLE DATA; Schema: public; Owner: db-user-foula
--

COPY public.books_readings (id, first_page, pages_count, created_at, updated_at, book_id, user_id) FROM stdin;
\.
COPY public.books_readings (id, first_page, pages_count, created_at, updated_at, book_id, user_id) FROM '$$PATH$$/3431.dat';

--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: db-user-foula
--

COPY public.category (id, name, created_at, updated_at) FROM stdin;
\.
COPY public.category (id, name, created_at, updated_at) FROM '$$PATH$$/3419.dat';

--
-- Data for Name: claim; Type: TABLE DATA; Schema: public; Owner: db-user-foula
--

COPY public.claim (id, claim_name, module_name, read, "create", update, delete, created_at, updated_at) FROM stdin;
\.
COPY public.claim (id, claim_name, module_name, read, "create", update, delete, created_at, updated_at) FROM '$$PATH$$/3423.dat';

--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: db-user-foula
--

COPY public.role (id, name, created_at, updated_at) FROM stdin;
\.
COPY public.role (id, name, created_at, updated_at) FROM '$$PATH$$/3429.dat';

--
-- Data for Name: roles_claims; Type: TABLE DATA; Schema: public; Owner: db-user-foula
--

COPY public.roles_claims (role_id, claim_id) FROM stdin;
\.
COPY public.roles_claims (role_id, claim_id) FROM '$$PATH$$/3433.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: db-user-foula
--

COPY public."user" (id, email, phone, password, created_at, updated_at, role_id) FROM stdin;
\.
COPY public."user" (id, email, phone, password, created_at, updated_at, role_id) FROM '$$PATH$$/3427.dat';

--
-- Data for Name: users_books_readings; Type: TABLE DATA; Schema: public; Owner: db-user-foula
--

COPY public.users_books_readings (book_id, user_id, unique_read_pages, total_read_pages, created_at, updated_at) FROM stdin;
\.
COPY public.users_books_readings (book_id, user_id, unique_read_pages, total_read_pages, created_at, updated_at) FROM '$$PATH$$/3436.dat';

--
-- Data for Name: users_profiles; Type: TABLE DATA; Schema: public; Owner: db-user-foula
--

COPY public.users_profiles (id, first_name, last_name, gender, address, birth_date, created_at, updated_at, auth_user_id) FROM stdin;
\.
COPY public.users_profiles (id, first_name, last_name, gender, address, birth_date, created_at, updated_at, auth_user_id) FROM '$$PATH$$/3425.dat';

--
-- Name: author_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db-user-foula
--

SELECT pg_catalog.setval('public.author_id_seq', 3, true);


--
-- Name: book_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db-user-foula
--

SELECT pg_catalog.setval('public.book_id_seq', 13, true);


--
-- Name: books_readings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db-user-foula
--

SELECT pg_catalog.setval('public.books_readings_id_seq', 49, true);


--
-- Name: category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db-user-foula
--

SELECT pg_catalog.setval('public.category_id_seq', 1, false);


--
-- Name: claim_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db-user-foula
--

SELECT pg_catalog.setval('public.claim_id_seq', 6, true);


--
-- Name: role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db-user-foula
--

SELECT pg_catalog.setval('public.role_id_seq', 1, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db-user-foula
--

SELECT pg_catalog.setval('public.user_id_seq', 11, true);


--
-- Name: users_profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db-user-foula
--

SELECT pg_catalog.setval('public.users_profiles_id_seq', 6, true);


--
-- Name: claim PK_466b305cc2e591047fa1ce58f81; Type: CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.claim
    ADD CONSTRAINT "PK_466b305cc2e591047fa1ce58f81" PRIMARY KEY (id);


--
-- Name: author PK_5a0e79799d372fe56f2f3fa6871; Type: CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.author
    ADD CONSTRAINT "PK_5a0e79799d372fe56f2f3fa6871" PRIMARY KEY (id);


--
-- Name: category PK_9c4e4a89e3674fc9f382d733f03; Type: CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT "PK_9c4e4a89e3674fc9f382d733f03" PRIMARY KEY (id);


--
-- Name: book PK_a3afef72ec8f80e6e5c310b28a4; Type: CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.book
    ADD CONSTRAINT "PK_a3afef72ec8f80e6e5c310b28a4" PRIMARY KEY (id);


--
-- Name: role PK_b36bcfe02fc8de3c57a8b2391c2; Type: CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT "PK_b36bcfe02fc8de3c57a8b2391c2" PRIMARY KEY (id);


--
-- Name: user PK_cace4a159ff9f2512dd42373760; Type: CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT "PK_cace4a159ff9f2512dd42373760" PRIMARY KEY (id);


--
-- Name: users_books_readings PK_d14ba4fa661f7a7d1ab2af63f1a; Type: CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.users_books_readings
    ADD CONSTRAINT "PK_d14ba4fa661f7a7d1ab2af63f1a" PRIMARY KEY (book_id, user_id);


--
-- Name: books_categories PK_dd273b23cf830ed55de0c199393; Type: CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.books_categories
    ADD CONSTRAINT "PK_dd273b23cf830ed55de0c199393" PRIMARY KEY (book_id, category_id);


--
-- Name: books_readings PK_e0aefabd373e17ccead29a5ea59; Type: CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.books_readings
    ADD CONSTRAINT "PK_e0aefabd373e17ccead29a5ea59" PRIMARY KEY (id);


--
-- Name: roles_claims PK_e267ebd3f54b40defb6ce005625; Type: CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.roles_claims
    ADD CONSTRAINT "PK_e267ebd3f54b40defb6ce005625" PRIMARY KEY (role_id, claim_id);


--
-- Name: users_profiles PK_e7a7f7db3fc96700d9239e43cda; Type: CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.users_profiles
    ADD CONSTRAINT "PK_e7a7f7db3fc96700d9239e43cda" PRIMARY KEY (id);


--
-- Name: users_profiles REL_28ba334a6a52cc5dac34e082ac; Type: CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.users_profiles
    ADD CONSTRAINT "REL_28ba334a6a52cc5dac34e082ac" UNIQUE (auth_user_id);


--
-- Name: IDX_68abbeb9a2e069557a635fb8ce; Type: INDEX; Schema: public; Owner: db-user-foula
--

CREATE INDEX "IDX_68abbeb9a2e069557a635fb8ce" ON public.roles_claims USING btree (role_id);


--
-- Name: IDX_a3da1b2593720b806144c065cb; Type: INDEX; Schema: public; Owner: db-user-foula
--

CREATE INDEX "IDX_a3da1b2593720b806144c065cb" ON public.roles_claims USING btree (claim_id);


--
-- Name: IDX_a7267f91a94721a1b11c9a2f6a; Type: INDEX; Schema: public; Owner: db-user-foula
--

CREATE INDEX "IDX_a7267f91a94721a1b11c9a2f6a" ON public.books_categories USING btree (category_id);


--
-- Name: IDX_ed5b61edeb35368078e032f5ca; Type: INDEX; Schema: public; Owner: db-user-foula
--

CREATE INDEX "IDX_ed5b61edeb35368078e032f5ca" ON public.books_categories USING btree (book_id);


--
-- Name: users_books_readings FK_17b251ff60a24eccc37201e3d99; Type: FK CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.users_books_readings
    ADD CONSTRAINT "FK_17b251ff60a24eccc37201e3d99" FOREIGN KEY (book_id) REFERENCES public.book(id);


--
-- Name: book FK_24b753b0490a992a6941451f405; Type: FK CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.book
    ADD CONSTRAINT "FK_24b753b0490a992a6941451f405" FOREIGN KEY (author_id) REFERENCES public.author(id);


--
-- Name: users_profiles FK_28ba334a6a52cc5dac34e082ac3; Type: FK CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.users_profiles
    ADD CONSTRAINT "FK_28ba334a6a52cc5dac34e082ac3" FOREIGN KEY (auth_user_id) REFERENCES public."user"(id);


--
-- Name: roles_claims FK_68abbeb9a2e069557a635fb8ce0; Type: FK CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.roles_claims
    ADD CONSTRAINT "FK_68abbeb9a2e069557a635fb8ce0" FOREIGN KEY (role_id) REFERENCES public.role(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: books_readings FK_9c4ebce22d27212458869ba45ab; Type: FK CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.books_readings
    ADD CONSTRAINT "FK_9c4ebce22d27212458869ba45ab" FOREIGN KEY (book_id) REFERENCES public.book(id);


--
-- Name: roles_claims FK_a3da1b2593720b806144c065cb4; Type: FK CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.roles_claims
    ADD CONSTRAINT "FK_a3da1b2593720b806144c065cb4" FOREIGN KEY (claim_id) REFERENCES public.claim(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: books_categories FK_a7267f91a94721a1b11c9a2f6a7; Type: FK CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.books_categories
    ADD CONSTRAINT "FK_a7267f91a94721a1b11c9a2f6a7" FOREIGN KEY (category_id) REFERENCES public.category(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users_books_readings FK_dca9e75f651c9ffe204e1f6bd8b; Type: FK CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.users_books_readings
    ADD CONSTRAINT "FK_dca9e75f651c9ffe204e1f6bd8b" FOREIGN KEY (user_id) REFERENCES public.users_profiles(id);


--
-- Name: books_categories FK_ed5b61edeb35368078e032f5ca2; Type: FK CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.books_categories
    ADD CONSTRAINT "FK_ed5b61edeb35368078e032f5ca2" FOREIGN KEY (book_id) REFERENCES public.book(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user FK_fb2e442d14add3cefbdf33c4561; Type: FK CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT "FK_fb2e442d14add3cefbdf33c4561" FOREIGN KEY (role_id) REFERENCES public.role(id);


--
-- Name: books_readings FK_fc92b5c36b4559fef9048422e30; Type: FK CONSTRAINT; Schema: public; Owner: db-user-foula
--

ALTER TABLE ONLY public.books_readings
    ADD CONSTRAINT "FK_fc92b5c36b4559fef9048422e30" FOREIGN KEY (user_id) REFERENCES public.users_profiles(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: db-user-foula
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

